#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/unsupported/Eigen/MatrixFunctions>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* --------------------------------------------------------------------*/
    /* perturbation
    /* --------------------------------------------------------------------*/
    Eigen::Quaterniond qi(1., 0., 1., 2.);
    // Must normolize,only unit quaternion can represent rotation
    qi.normalize();
    Eigen::Matrix3d Ri = qi.toRotationMatrix();
    Eigen::Vector3d w(0.01, 0.02, 0.03);
    // propagate on quaternion
    Eigen::Quaterniond deltaQ(1, 0.5*w(0), 0.5*w(1), 0.5*w(2));
    deltaQ.normalize();
    Eigen::Quaterniond qj = qi*deltaQ;
    cout << "propagate on quaternion : " << endl << qj.w() << ", " << qj.x() << ", " << qj.y() << ", " << qj.z() << endl;
    //Eigen::Matrix3d R_qj = qj.toRotationMatrix();
    //cout << "propagate on quaternion : " << endl << R_qj << endl;
    // propagate on rotation matrix
    Eigen::Matrix3d skew_symmetric;
    skew_symmetric << 0, -w(2), w(1),
                      w(2), 0, -w(0),
                      -w(1), w(0), 0;
    Eigen::Matrix3d Rj = Ri*skew_symmetric.exp();
    //cout << "propagate on rotation matrix: " << endl << Rj << endl;
    Eigen::Quaterniond q_j_R(Rj);
    cout << "propagate on rotation matrix: " << endl<< q_j_R.w() << ", " << q_j_R.x() << ", " << q_j_R.y() << ", " << q_j_R.z() << endl;

    return 0;
}
